public interface Automobile  {

    public void numberOfSeats (int numberOfSeats);
    public void cargoSpace (int numberOfSuitCases);

}

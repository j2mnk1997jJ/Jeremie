public abstract class Vehicle {

    public abstract void accelerate(int accelerationTo100);
    public abstract void stop(int stoppageFrom100);
    public abstract void gas(int litresPerKm);
}

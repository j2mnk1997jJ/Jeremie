public class Main {

    public static void main(String[] args) {

        Building [] building = new Building[5];

        building [0] = new Building("One River",5,3,"Yellow");
        building [1] = new Building("Nyayo House",15,10,"Grey");
        building [2] = new Building("Student Center",5,15,"Black");
        building [3] = new Building("International House",20,25,"Blue");
        building [4] = new Building("Kimathi Chambers",10,15,"White");

        System.out.println("-----Start of Report--------------");
        for(int i = 0;i<building.length;i++){
            building[i].printBuilding();
        }
        System.out.println("------End of Report-------");

    }

}

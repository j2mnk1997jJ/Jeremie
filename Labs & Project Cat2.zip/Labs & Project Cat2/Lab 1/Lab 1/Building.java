public class Building {



    String nameOfBuilding;
    int numberOfFloors;
    int numberOfRoomsPerFloor;
    String color;

    public Building(String nameOfBuilding, int numberOfFloors, int numberOfRoomsPerFloor, String color) {
        this.nameOfBuilding = nameOfBuilding;
        this.numberOfFloors = numberOfFloors;
        this.numberOfRoomsPerFloor = numberOfRoomsPerFloor;
        this.color = color;
    }

    public String getNameOfBuilding() {
        return nameOfBuilding;
    }

    public int getNumberOfFloors() {
        return numberOfFloors;
    }

    public int getNumberOfRoomsPerFloor() {
        return numberOfRoomsPerFloor;
    }

    public String getColor() {
        return color;
    }

    public void printBuilding(){
        System.out.println("<<"+getNameOfBuilding()+">> is a <<"+color+">> and has <<"+getNumberOfFloors()*getNumberOfRoomsPerFloor()+">> rooms." );
    }
}
